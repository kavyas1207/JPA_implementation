package com.sample.project.constants;

import org.springframework.stereotype.Component;

@Component
public class ReturnMSG {
	public ReturnMSG()
	{
		
	}
	public static final String DELETED_BUYER="User got deleted with contactno"; 
}
